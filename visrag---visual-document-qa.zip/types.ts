export interface UploadedImage {
  id: string;
  data: string; // Base64 string
  mimeType: string;
  name: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  isError?: boolean;
}

export interface SavedSession {
  id: string;
  timestamp: number;
  title: string;
  messages: Message[];
  images: UploadedImage[];
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
}

export type AIProvider = 'gemini' | 'local';

export interface AISettings {
  provider: AIProvider;
  // Local Config
  localBaseUrl: string; // e.g., http://localhost:11434/v1
  localModelName: string; // e.g., llava
  // Cloud Config (Optional override, usually from env)
  apiKey?: string;
}