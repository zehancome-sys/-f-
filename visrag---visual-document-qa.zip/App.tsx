import React, { useState, useCallback, useEffect } from 'react';
import { UploadedImage, Message, SavedSession, AISettings } from './types';
import { Uploader } from './components/Uploader';
import { ChatInterface } from './components/ChatInterface';
import { DocumentViewer } from './components/DocumentViewer';
import { SettingsModal } from './components/SettingsModal';
import { queryVisRAG } from './services/aiService';

// Default Settings
const DEFAULT_SETTINGS: AISettings = {
    provider: 'gemini',
    localBaseUrl: 'http://localhost:11434/v1',
    localModelName: 'llava'
};

const App: React.FC = () => {
  // --- State ---
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessions, setSessions] = useState<SavedSession[]>([]);
  const [settings, setSettings] = useState<AISettings>(() => {
      const saved = localStorage.getItem('finrag_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarTab, setSidebarTab] = useState<'docs' | 'history'>('docs');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toast, setToast] = useState<{msg: string, type: 'success' | 'error' | 'info'} | null>(null);

  // --- Helpers ---
  const showToast = (msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSaveSettings = (newSettings: AISettings) => {
      setSettings(newSettings);
      localStorage.setItem('finrag_settings', JSON.stringify(newSettings));
      showToast(`Switched to ${newSettings.provider === 'local' ? 'Local Model' : 'Cloud API'}`, 'success');
  };

  const handleImagesSelected = useCallback((newImages: UploadedImage[]) => {
    setImages(prev => [...prev, ...newImages]);
    if (newImages.length > 0) {
      setSelectedImageId(newImages[0].id);
      setSidebarTab('docs'); // Ensure we see the docs
    }
  }, []);

  // --- Session Management ---
  const handleNewChat = () => {
    // Save current session if it has content
    if (messages.length > 0 || images.length > 0) {
        const title = messages.length > 0 
            ? (messages[0].content.length > 25 ? messages[0].content.substring(0, 25) + '...' : messages[0].content)
            : `Analysis ${new Date().toLocaleTimeString()}`;
            
        const newSession: SavedSession = {
            id: Date.now().toString(),
            timestamp: Date.now(),
            title: title,
            messages: [...messages],
            images: [...images]
        };
        setSessions(prev => [newSession, ...prev]);
    }

    // Reset workspace
    setImages([]);
    setMessages([]);
    setSelectedImageId(null);
    setSidebarTab('docs');
    showToast("Started new secure session", 'success');
  };

  const handleLoadSession = (session: SavedSession) => {
    setImages(session.images);
    setMessages(session.messages);
    if (session.images.length > 0) {
        setSelectedImageId(session.images[0].id);
    }
    setSidebarTab('docs');
    showToast("Restored previous session", 'info');
  };

  // --- Global Paste Handler ---
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      const newImages: UploadedImage[] = [];
      let processed = 0;
      let expected = 0;
      let hasImage = false;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          hasImage = true;
          expected++;
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onload = (event) => {
              if (event.target?.result) {
                newImages.push({
                  id: Math.random().toString(36).substr(2, 9),
                  name: `Pasted-${new Date().toLocaleTimeString()}.png`,
                  mimeType: blob.type,
                  data: event.target.result as string
                });
                processed++;
                if (processed === expected) {
                    handleImagesSelected(newImages);
                    showToast(`Imported ${newImages.length} image(s) from clipboard`, 'success');
                }
              }
            };
            reader.readAsDataURL(blob);
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [handleImagesSelected]);

  // --- Drag & Drop Handlers ---
  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); if(e.currentTarget === e.target) setIsDragging(false); };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (files.length === 0) return;

    const newImages: UploadedImage[] = [];
    let processed = 0;
    files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
            if (event.target?.result) {
                newImages.push({
                    id: Math.random().toString(36).substr(2, 9),
                    name: file.name,
                    mimeType: file.type,
                    data: event.target.result as string
                });
                processed++;
                if (processed === files.length) {
                    handleImagesSelected(newImages);
                    showToast(`Imported ${files.length} document(s)`, 'success');
                }
            }
        };
        reader.readAsDataURL(file);
    });
  };

  const handleDeleteImage = (id: string) => {
    const newImages = images.filter(img => img.id !== id);
    setImages(newImages);
    if (selectedImageId === id) {
      setSelectedImageId(newImages.length > 0 ? newImages[0].id : null);
    }
  };

  const handleSendMessage = useCallback(async (text: string) => {
    if (images.length === 0) {
        showToast("Please paste or upload a document first.", "error");
        return;
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: Date.now()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // Pass settings to the unified service
      const responseText = await queryVisRAG(text, images, messages, settings);
      const modelMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: responseText,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (error: any) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: `Error: ${error.message}`,
        timestamp: Date.now(),
        isError: true
      };
      setMessages(prev => [...prev, errorMsg]);
      showToast("Analysis failed", "error");
    } finally {
      setIsLoading(false);
    }
  }, [images, messages, settings]);

  const activeImage = images.find(img => img.id === selectedImageId);

  return (
    <div 
        className="h-screen w-full flex flex-col bg-slate-50 text-slate-900 font-sans overflow-hidden"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
    >
      <SettingsModal 
        isOpen={settingsOpen} 
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onSave={handleSaveSettings}
      />

      {/* Toast Notification */}
      {toast && (
          <div className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] px-6 py-2 rounded-full shadow-lg text-sm font-medium transition-all animate-fade-in-down ${
              toast.type === 'error' ? 'bg-red-500 text-white' : 
              toast.type === 'success' ? 'bg-emerald-600 text-white' : 
              'bg-slate-800 text-white'
          }`}>
              {toast.msg}
          </div>
      )}

      {/* Drag Overlay */}
      {isDragging && (
        <div className="absolute inset-0 z-50 bg-emerald-600/20 backdrop-blur-sm flex items-center justify-center pointer-events-none">
            <div className="bg-white p-8 rounded-xl shadow-2xl flex flex-col items-center animate-bounce border-2 border-emerald-500">
                <svg className="w-16 h-16 text-emerald-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                <p className="font-bold text-xl text-slate-800">Drop Financial Documents</p>
            </div>
        </div>
      )}

      {/* Header */}
      <header className="h-14 bg-white border-b border-slate-200 flex items-center px-4 justify-between flex-shrink-0 z-20 shadow-sm">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded flex items-center justify-center text-white font-bold text-lg shadow-sm transition-colors ${settings.provider === 'local' ? 'bg-blue-600' : 'bg-emerald-600'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
          </div>
          <h1 className="font-bold text-lg text-slate-800 tracking-tight">
            FinRAG 
            <span className={`font-normal text-xs ml-2 px-2 py-0.5 rounded border ${
                settings.provider === 'local' 
                ? 'bg-blue-50 text-blue-700 border-blue-100' 
                : 'bg-emerald-50 text-emerald-700 border-emerald-100'
            }`}>
                {settings.provider === 'local' ? `Local: ${settings.localModelName}` : 'Cloud: Gemini 2.5'}
            </span>
          </h1>
        </div>
        <div className="flex items-center gap-3">
           
           {/* Settings Button */}
           <button 
                onClick={() => setSettingsOpen(true)}
                className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                title="Connection Settings"
           >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
           </button>

           <div className="h-6 w-px bg-slate-200 mx-1"></div>

           <button 
                onClick={handleNewChat}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-white text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-medium border border-slate-200 transition-colors shadow-sm"
           >
             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
             New Chat
           </button>
           
           <button onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden text-slate-500">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg>
           </button>
        </div>
      </header>

      {/* Main Layout */}
      <main className="flex-1 flex overflow-hidden">
        
        {/* COL 1: Document/History Sidebar */}
        <div className={`${sidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 bg-slate-50 border-r border-slate-200 flex flex-col flex-shrink-0 relative`}>
            
            {/* Sidebar Tabs */}
            <div className="flex border-b border-slate-200 bg-white">
                <button 
                    onClick={() => setSidebarTab('docs')}
                    className={`flex-1 py-3 text-xs font-medium text-center border-b-2 transition-colors ${sidebarTab === 'docs' ? 'border-emerald-500 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
                >
                    Docs ({images.length})
                </button>
                <button 
                    onClick={() => setSidebarTab('history')}
                    className={`flex-1 py-3 text-xs font-medium text-center border-b-2 transition-colors ${sidebarTab === 'history' ? 'border-emerald-500 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
                >
                    History ({sessions.length})
                </button>
            </div>

            {/* TAB: Current Docs */}
            {sidebarTab === 'docs' && (
                <>
                    <div className="p-3 border-b border-slate-200 bg-white sticky top-0 z-10">
                        <Uploader onImagesSelected={handleImagesSelected} />
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-2 space-y-2">
                        {images.length === 0 && (
                            <div className="text-center p-4 text-xs text-slate-400 mt-10">
                                No active documents.<br/>Paste (Ctrl+V) or upload.
                            </div>
                        )}
                        {images.map((img, idx) => (
                            <div 
                                key={img.id}
                                onClick={() => setSelectedImageId(img.id)}
                                className={`group relative flex items-center gap-3 p-2 rounded border transition-all cursor-pointer ${
                                    selectedImageId === img.id 
                                    ? 'bg-white border-emerald-500 shadow-sm ring-1 ring-emerald-50' 
                                    : 'bg-white border-slate-200 hover:border-emerald-300'
                                }`}
                            >
                                <div className="w-10 h-10 bg-slate-100 rounded overflow-hidden flex-shrink-0 border border-slate-100 flex items-center justify-center">
                                     <img src={img.data} alt="thumb" className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className={`text-xs font-medium truncate ${selectedImageId === img.id ? 'text-emerald-700' : 'text-slate-700'}`}>
                                        {img.name}
                                    </p>
                                    <p className="text-[10px] text-slate-400">Doc {idx + 1}</p>
                                </div>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleDeleteImage(img.id); }}
                                    className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                </button>
                            </div>
                        ))}
                    </div>
                </>
            )}

            {/* TAB: History */}
            {sidebarTab === 'history' && (
                <div className="flex-1 overflow-y-auto p-2 space-y-2">
                    {sessions.length === 0 && (
                        <div className="text-center p-4 text-xs text-slate-400 mt-10">
                            No saved sessions.<br/>Click "New Chat" to archive current work.
                        </div>
                    )}
                    {sessions.map((session) => (
                        <div 
                            key={session.id}
                            onClick={() => handleLoadSession(session)}
                            className="p-3 bg-white border border-slate-200 rounded hover:border-emerald-300 cursor-pointer transition-all shadow-sm hover:shadow-md"
                        >
                            <p className="text-xs font-semibold text-slate-700 truncate mb-1">{session.title}</p>
                            <div className="flex justify-between items-center text-[10px] text-slate-400">
                                <span>{new Date(session.timestamp).toLocaleDateString()}</span>
                                <span>{session.images.length} docs</span>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>

        {/* COL 2: Main Document Viewer */}
        <div className="flex-1 bg-slate-200/50 relative flex flex-col min-w-0">
            <div className="flex-1 overflow-hidden relative p-4 flex items-center justify-center">
                {activeImage ? (
                    <div className="w-full h-full shadow-lg rounded-sm overflow-hidden border border-slate-300/50">
                        <DocumentViewer src={activeImage.data} alt={activeImage.name} />
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400 opacity-70">
                        <div className="w-16 h-16 bg-slate-200 rounded-lg flex items-center justify-center mb-4 text-slate-400">
                             <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        </div>
                        <p className="font-medium text-sm">Paste Screenshot (Ctrl+V)</p>
                        <p className="text-xs mt-1">or drag & drop files here</p>
                    </div>
                )}
            </div>
            <div className="h-8 bg-white border-t border-slate-200 flex items-center px-4 justify-between text-xs text-slate-500">
                <span>{activeImage ? activeImage.name : 'Ready for data'}</span>
                <span>Zoom & Pan Enabled</span>
            </div>
        </div>

        {/* COL 3: Chat Interface */}
        <div className="w-[450px] border-l border-slate-200 bg-white flex flex-col flex-shrink-0 z-10 shadow-xl">
             <div className="flex-1 min-h-0">
                <ChatInterface 
                    messages={messages} 
                    onSendMessage={handleSendMessage}
                    isLoading={isLoading}
                    uploadedImages={images}
                />
             </div>
             <div className="p-2 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-400 text-center leading-tight">
                Disclaimer: AI-generated analysis may contain errors.<br/>Verify all figures against original documents before investing.
             </div>
        </div>

      </main>
    </div>
  );
};

export default App;