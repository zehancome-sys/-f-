import { GoogleGenAI } from "@google/genai";
import { UploadedImage, Message, AISettings } from "../types";

// System Prompt for Financial Analyst Persona
const SYSTEM_INSTRUCTION = `You are a Senior Financial Analyst and Auditor.
You are provided with images of financial documents (10-K, 10-Q, Balance Sheets, Earnings Slides, Stock Charts, etc.).

YOUR CORE PROTOCOLS:
1. **Precision is Paramount**: Read numbers exactly as they appear. Do not round numbers unless asked. If a number is blurry, state "illegible".
2. **Table Formatting**: When comparing periods (e.g., 2023 vs 2024) or entities, YOU MUST USE MARKDOWN TABLES.
3. **Terminology**: Use precise financial terminology (e.g., EBITDA, YoY, CAGR, EPS, Diluted vs Basic).
4. **Source Tracing**: When citing a figure, reference the context (e.g., "[Page 2 - Balance Sheet]").
5. **Trend Analysis**: When analyzing charts, describe the trend direction, volatility, and key support/resistance levels if applicable.

FORMATTING RULES:
- Use Markdown tables for all structured data.
- Use standard financial formatting (e.g., $1,234.56, (15.2%)).
- Use ### Headers for sections (e.g., "### Executive Summary").

Do not offer investment advice. Focus purely on data extraction and analytical synthesis.`;

/**
 * Main entry point for querying AI (Cloud or Local)
 */
export const queryVisRAG = async (
  currentPrompt: string,
  images: UploadedImage[],
  history: Message[],
  settings: AISettings
): Promise<string> => {
  if (settings.provider === 'local') {
    return queryLocalLLM(currentPrompt, images, history, settings);
  } else {
    return queryGemini(currentPrompt, images, history);
  }
};

/**
 * Handler for Gemini Cloud API
 */
const queryGemini = async (
  currentPrompt: string,
  images: UploadedImage[],
  history: Message[]
): Promise<string> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
      throw new Error("API Key is missing. Check .env or Settings.");
  }
  const ai = new GoogleGenAI({ apiKey: apiKey });
  const model = "gemini-3-flash-preview";

  const parts: any[] = [];

  // Add images
  images.forEach((img, index) => {
    const cleanBase64 = img.data.split(',')[1]; 
    parts.push({
      inlineData: {
        mimeType: img.mimeType,
        data: cleanBase64
      }
    });
    parts.push({ text: `[Document Image ${index + 1}]` });
  });

  // History
  let historyContext = "Conversation History:\n";
  history.forEach(msg => {
      historyContext += `${msg.role === 'user' ? 'User' : 'Analyst'}: ${msg.content}\n`;
  });
  
  parts.push({ text: `${historyContext}\n\nCurrent Task: ${currentPrompt}` });

  const response = await ai.models.generateContent({
    model: model,
    contents: { parts: parts },
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.0,
    },
  });

  return response.text || "No response received.";
};

/**
 * Handler for Local OpenAI-Compatible API (e.g., Ollama, LM Studio)
 */
const queryLocalLLM = async (
  currentPrompt: string,
  images: UploadedImage[],
  history: Message[],
  settings: AISettings
): Promise<string> => {
  const baseUrl = settings.localBaseUrl.replace(/\/+$/, ''); // remove trailing slash
  const endpoint = `${baseUrl}/chat/completions`;

  // Construct messages in OpenAI format
  // Note: Most local vision models (Llava) expect the image in the USER message
  
  const messages: any[] = [];

  // 1. Add System Prompt
  messages.push({ role: "system", content: SYSTEM_INSTRUCTION });

  // 2. Add History (Text only for history to save tokens/complexity on local models usually)
  history.forEach(msg => {
      messages.push({ role: msg.role === 'model' ? 'assistant' : 'user', content: msg.content });
  });

  // 3. Add Current Message with Images
  const contentParts: any[] = [];
  contentParts.push({ type: "text", text: currentPrompt });

  images.forEach(img => {
      contentParts.push({
          type: "image_url",
          image_url: {
              url: img.data // OpenAI format accepts data URI: data:image/jpeg;base64,...
          }
      });
  });

  messages.push({
      role: "user",
      content: contentParts
  });

  try {
      const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              // Add Authorization header if your local setup requires it
              // 'Authorization': `Bearer ${settings.apiKey || 'sk-xxxx'}` 
          },
          body: JSON.stringify({
              model: settings.localModelName,
              messages: messages,
              temperature: 0,
              stream: false
          })
      });

      if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Local LLM Error (${response.status}): ${errText}`);
      }

      const data = await response.json();
      return data.choices?.[0]?.message?.content || "No response from local model.";

  } catch (error: any) {
      console.error("Local LLM Request Failed:", error);
      if (error.message.includes("Failed to fetch")) {
          throw new Error("Connection failed. Is Ollama running? Did you enable CORS? (OLLAMA_ORIGINS='*')");
      }
      throw error;
  }
};