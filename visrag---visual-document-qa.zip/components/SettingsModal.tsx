import React, { useState } from 'react';
import { AISettings, AIProvider } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AISettings;
  onSave: (newSettings: AISettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave }) => {
  const [localSettings, setLocalSettings] = useState<AISettings>(settings);
  const [showHelp, setShowHelp] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center flex-shrink-0">
          <h3 className="font-bold text-slate-800">Connection Settings</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          
          {/* Provider Toggle */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">AI Provider</label>
            <div className="flex bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => setLocalSettings({...localSettings, provider: 'gemini'})}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${
                  localSettings.provider === 'gemini' 
                    ? 'bg-white text-emerald-600 shadow-sm ring-1 ring-emerald-100' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Google Gemini (Cloud)
              </button>
              <button
                onClick={() => setLocalSettings({...localSettings, provider: 'local'})}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${
                  localSettings.provider === 'local' 
                    ? 'bg-white text-blue-600 shadow-sm ring-1 ring-blue-100' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Local / Ollama
              </button>
            </div>
          </div>

          {/* Cloud Config */}
          {localSettings.provider === 'gemini' && (
             <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100">
                <p className="text-sm text-emerald-800 font-medium flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                    Using API Key from .env
                </p>
                <p className="text-xs text-emerald-600 mt-1 pl-6">
                    Model: gemini-3-flash-preview
                </p>
             </div>
          )}

          {/* Local Config */}
          {localSettings.provider === 'local' && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Base URL</label>
                <input 
                    type="text" 
                    value={localSettings.localBaseUrl}
                    onChange={(e) => setLocalSettings({...localSettings, localBaseUrl: e.target.value})}
                    placeholder="http://localhost:11434/v1"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
                <p className="text-[10px] text-slate-400 mt-1">Default for Ollama: <code>http://localhost:11434/v1</code></p>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Model Name</label>
                <input 
                    type="text" 
                    value={localSettings.localModelName}
                    onChange={(e) => setLocalSettings({...localSettings, localModelName: e.target.value})}
                    placeholder="llava"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
                <p className="text-[10px] text-slate-400 mt-1">Must support vision (e.g., <code>llava</code>, <code>llama3.2-vision</code>)</p>
              </div>

               {/* Collapsible Connection Guide */}
               <div className="border border-amber-200 rounded-lg overflow-hidden">
                  <button 
                    onClick={() => setShowHelp(!showHelp)}
                    className="w-full flex items-center justify-between px-3 py-2 bg-amber-50 text-amber-800 text-xs font-medium"
                  >
                    <span>⚠️ Connection Error? Read this first</span>
                    <svg className={`w-4 h-4 transition-transform ${showHelp ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                  </button>
                  
                  {showHelp && (
                    <div className="p-3 bg-amber-50/50 text-xs text-slate-700 space-y-3 border-t border-amber-100">
                        <div>
                            <p className="font-semibold text-amber-900 mb-1">Step 1: Fully Quit Ollama</p>
                            <p>Right-click the Ollama icon in your taskbar/menu bar and select "Quit".</p>
                        </div>
                        <div>
                            <p className="font-semibold text-amber-900 mb-1">Step 2: Run Command</p>
                            <p className="mb-1">You must allow browser requests (CORS). Copy and run this in your terminal:</p>
                            
                            <div className="mt-2">
                                <span className="text-[10px] font-bold text-slate-500 uppercase">Windows (PowerShell)</span>
                                <div className="relative group">
                                    <code className="block bg-slate-800 text-green-400 p-2 rounded mt-1 select-all cursor-text font-mono">
                                        $env:OLLAMA_ORIGINS="*"; ollama serve
                                    </code>
                                </div>
                            </div>
                            
                            <div className="mt-2">
                                <span className="text-[10px] font-bold text-slate-500 uppercase">Mac / Linux</span>
                                <div className="relative group">
                                    <code className="block bg-slate-800 text-green-400 p-2 rounded mt-1 select-all cursor-text font-mono">
                                        OLLAMA_ORIGINS="*" ollama serve
                                    </code>
                                </div>
                            </div>
                        </div>
                    </div>
                  )}
               </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3 flex-shrink-0">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            className={`px-4 py-2 text-sm font-medium text-white rounded-lg shadow-sm transition-colors ${
                localSettings.provider === 'local' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};