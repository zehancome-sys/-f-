import React, { useCallback } from 'react';
import { UploadedImage } from '../types';

interface UploaderProps {
  onImagesSelected: (images: UploadedImage[]) => void;
}

export const Uploader: React.FC<UploaderProps> = ({ onImagesSelected }) => {
  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const newImages: UploadedImage[] = [];
    // Filter for valid images first to establish a reliable target count.
    // This prevents the process from hanging if a non-image file is selected.
    const validFiles = Array.from(files).filter(file => file.type.startsWith('image/'));

    if (validFiles.length === 0) {
      // If no valid images were selected, just reset.
      event.target.value = '';
      return;
    }

    let processedCount = 0;
    
    // Function to check if all files are processed
    const checkCompletion = () => {
      processedCount++;
      if (processedCount === validFiles.length) {
        onImagesSelected(newImages);
        // Reset input to allow selecting the same file again if needed
        event.target.value = '';
      }
    };

    validFiles.forEach((file) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        if (e.target?.result) {
          newImages.push({
            id: Math.random().toString(36).substr(2, 9),
            name: file.name,
            mimeType: file.type,
            data: e.target.result as string,
          });
        }
        checkCompletion();
      };

      reader.onerror = () => {
        console.error(`Failed to read file: ${file.name}`);
        checkCompletion();
      };

      reader.readAsDataURL(file);
    });
  }, [onImagesSelected]);

  return (
    <div className="w-full">
      <label 
        htmlFor="doc-upload"
        className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 border-dashed rounded-xl cursor-pointer bg-slate-50 hover:bg-blue-50 hover:border-blue-400 transition-colors group"
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <svg className="w-8 h-8 mb-3 text-slate-400 group-hover:text-blue-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"/>
          </svg>
          <p className="mb-1 text-sm text-slate-500 group-hover:text-blue-600 font-medium">Click to upload</p>
          <p className="text-xs text-slate-400">PNG, JPG</p>
        </div>
        <input id="doc-upload" type="file" className="hidden" multiple accept="image/*" onChange={handleFileChange} />
      </label>
    </div>
  );
};