import React from 'react';

// Block types for the parser
type BlockType = 'text' | 'code' | 'table';

interface Block {
  type: BlockType;
  content: string[];
}

export const MarkdownText: React.FC<{ content: string }> = ({ content }) => {
  // Pre-process content into blocks to handle tables correctly
  const blocks: Block[] = [];
  const lines = content.split('\n');
  let currentBlock: Block = { type: 'text', content: [] };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    // 1. Code Block Detection
    if (trimmed.startsWith('```')) {
      // Close current block
      if (currentBlock.content.length > 0) blocks.push(currentBlock);
      
      // If we were in code, switch to text. If in text, switch to code.
      // But since we want to capture the content INSIDE, we treat this toggle differently.
      // Simplify: Just treat the block inside ``` as a code block
      if (currentBlock.type === 'code') {
          // End of code block
          currentBlock = { type: 'text', content: [] };
      } else {
          // Start of code block
          currentBlock = { type: 'code', content: [] };
      }
      continue; 
    }

    // 2. Table Detection
    // A table line usually starts with |
    if (trimmed.startsWith('|') && currentBlock.type !== 'code') {
        if (currentBlock.type !== 'table') {
            if (currentBlock.content.length > 0) blocks.push(currentBlock);
            currentBlock = { type: 'table', content: [] };
        }
        currentBlock.content.push(line);
        continue;
    }

    // 3. Regular Text
    // If we were in a table but this line isn't a table row, close the table
    if (currentBlock.type === 'table' && !trimmed.startsWith('|')) {
        blocks.push(currentBlock);
        currentBlock = { type: 'text', content: [] };
    }

    currentBlock.content.push(line);
  }
  if (currentBlock.content.length > 0) blocks.push(currentBlock);

  // Render Blocks
  return (
    <div className="space-y-3 text-sm leading-relaxed font-sans text-slate-800">
      {blocks.map((block, idx) => {
        if (block.type === 'code') {
            return (
                <div key={idx} className="bg-slate-900 text-slate-50 font-mono text-xs p-3 rounded-lg overflow-x-auto shadow-sm my-2">
                    <pre>{block.content.join('\n')}</pre>
                </div>
            );
        }
        if (block.type === 'table') {
            return <TableBlock key={idx} lines={block.content} />;
        }
        return <TextBlock key={idx} lines={block.content} />;
      })}
    </div>
  );
};

// Sub-component for rendering Tables
const TableBlock: React.FC<{ lines: string[] }> = ({ lines }) => {
    // Basic markdown table parser
    // Expects: | Header | Header |
    //          | --- | --- |
    //          | Data | Data |
    const headers = lines[0]?.split('|').filter(c => c.trim() !== '').map(c => c.trim()) || [];
    const rows = lines.slice(2).map(line => 
        line.split('|').filter(c => c.trim() !== '' || line.trim().endsWith('|')).map(c => c.trim()) // simple split logic
    );

    return (
        <div className="overflow-x-auto my-4 border border-slate-200 rounded-lg shadow-sm">
            <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                    <tr>
                        {headers.map((h, i) => (
                            <th key={i} className="px-3 py-2 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">
                                {h}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                    {rows.map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-slate-50/50">
                            {row.map((cell, cIdx) => (
                                <td key={cIdx} className="px-3 py-2 text-xs text-slate-700 whitespace-pre-wrap font-mono tabular-nums">
                                    {cell}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

// Sub-component for text with basic formatting
const TextBlock: React.FC<{ lines: string[] }> = ({ lines }) => {
    return (
        <div className="space-y-1">
            {lines.map((line, i) => {
                const trimmed = line.trim();
                if (!trimmed) return <div key={i} className="h-2" />;
                
                // Headers
                if (trimmed.startsWith('### ')) return <h3 key={i} className="text-slate-900 font-bold text-base mt-4 mb-2">{trimmed.substring(4)}</h3>;
                if (trimmed.startsWith('## ')) return <h2 key={i} className="text-slate-900 font-bold text-lg mt-6 mb-3 pb-1 border-b border-slate-200">{trimmed.substring(3)}</h2>;
                
                // Bullets
                if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
                    return (
                         <div key={i} className="flex gap-2 ml-1">
                            <span className="text-blue-600 mt-1.5 text-[6px] flex-shrink-0">●</span>
                            <span dangerouslySetInnerHTML={{ __html: parseStyles(trimmed.substring(2)) }} />
                        </div>
                    );
                }

                 // Standard Text
                return <div key={i} dangerouslySetInnerHTML={{ __html: parseStyles(line) }} />;
            })}
        </div>
    );
}

const parseStyles = (text: string) => {
  let processed = text;
  // Bold **text**
  processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-slate-900">$1</strong>');
  // Italic *text*
  processed = processed.replace(/\*(.*?)\*/g, '<em class="text-slate-600">$1</em>');
  // Inline code `text`
  processed = processed.replace(/`(.*?)`/g, '<code class="bg-slate-100 text-slate-700 px-1 py-0.5 rounded font-mono text-xs border border-slate-200">$1</code>');
  return processed;
};