import React, { useState, useRef, useEffect } from 'react';

interface DocumentViewerProps {
  src: string;
  alt: string;
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({ src, alt }) => {
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  // Reset view when image changes
  useEffect(() => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, [src]);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const scaleAdjustment = -e.deltaY * 0.001;
    const newScale = Math.min(Math.max(0.5, scale + scaleAdjustment), 5);
    setScale(newScale);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      e.preventDefault();
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full bg-slate-200 overflow-hidden flex items-center justify-center cursor-move rounded-xl border border-slate-300 shadow-inner"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2 bg-white/90 backdrop-blur rounded-lg shadow-sm border border-slate-200 p-1">
        <button 
            onClick={(e) => { e.stopPropagation(); setScale(s => Math.min(s + 0.2, 5)); }}
            className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded text-slate-600 font-bold"
        >+</button>
        <button 
            onClick={(e) => { e.stopPropagation(); setScale(1); setPosition({x:0,y:0}); }}
            className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded text-slate-600 text-xs"
        >1:1</button>
        <button 
            onClick={(e) => { e.stopPropagation(); setScale(s => Math.max(0.5, s - 0.2)); }}
            className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded text-slate-600 font-bold"
        >-</button>
      </div>

      <img
        src={src}
        alt={alt}
        draggable={false}
        style={{
          transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
          transition: isDragging ? 'none' : 'transform 0.1s ease-out',
          maxWidth: '90%',
          maxHeight: '90%'
        }}
        className="select-none shadow-xl"
      />
      
      <div className="absolute bottom-4 left-4 bg-black/60 text-white text-xs px-2 py-1 rounded backdrop-blur-sm pointer-events-none">
        Scroll to Zoom • Drag to Pan
      </div>
    </div>
  );
};