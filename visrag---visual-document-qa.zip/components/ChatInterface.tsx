import React, { useState, useRef, useEffect } from 'react';
import { Message, UploadedImage } from '../types';
import { Button } from './Button';
import { MarkdownText } from './MarkdownText';

interface ChatInterfaceProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  uploadedImages: UploadedImage[];
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  messages, 
  onSendMessage, 
  isLoading,
  uploadedImages 
}) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input);
    setInput('');
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Chat Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
            <div>
                <h2 className="font-semibold text-slate-800">Analyst Assistant</h2>
                <p className="text-xs text-slate-500">
                    {uploadedImages.length > 0 
                        ? `${uploadedImages.length} active documents` 
                        : 'Waiting for documents...'}
                </p>
            </div>
            {/* Status indicator removed here as it's now in the main App header */}
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-white">
            {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60">
                    <svg className="w-16 h-16 mb-4 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                    <p className="text-center text-sm font-medium">FinRAG Environment Ready</p>
                    <p className="text-center text-xs mt-1 max-w-[200px]">Paste images (Ctrl+V) anywhere or upload to begin analysis.</p>
                </div>
            )}
            
            {messages.map((msg) => (
                <div 
                    key={msg.id} 
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                    <div 
                        className={`max-w-[90%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                            msg.role === 'user' 
                            ? 'bg-emerald-600 text-white rounded-br-none shadow-sm' 
                            : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200'
                        } ${msg.isError ? 'bg-red-50 border-red-200 text-red-600' : ''}`}
                    >
                        {msg.role === 'model' ? (
                           <MarkdownText content={msg.content} />
                        ) : (
                           <span className="whitespace-pre-wrap">{msg.content}</span>
                        )}
                    </div>
                </div>
            ))}
            {isLoading && (
                <div className="flex justify-start">
                    <div className="bg-slate-100 rounded-2xl rounded-bl-none px-4 py-3 border border-slate-200">
                        <div className="flex space-x-2">
                            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                        </div>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-slate-100">
            <form onSubmit={handleSubmit} className="relative group">
                <input
                    ref={inputRef}
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={uploadedImages.length > 0 ? "Ask a financial question..." : "Paste (Ctrl+V) images or upload first..."}
                    className={`w-full pl-4 pr-24 py-3 rounded-xl border outline-none transition-all placeholder:text-slate-400
                        ${uploadedImages.length === 0 
                            ? 'border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-300 focus:ring-2 focus:ring-emerald-100' 
                            : 'border-slate-300 focus:ring-2 focus:ring-emerald-100 focus:border-emerald-500'
                        }
                    `}
                    disabled={isLoading} 
                />
                <div className="absolute right-2 top-2">
                    <Button 
                        type="submit" 
                        variant="primary" 
                        disabled={!input.trim() || isLoading}
                        className={`!px-3 !py-1.5 !text-xs !h-8 ${uploadedImages.length === 0 ? 'bg-slate-400 hover:bg-slate-500' : 'bg-emerald-600 hover:bg-emerald-700'}`}
                    >
                        Send
                    </Button>
                </div>
            </form>
            <p className="text-center text-[10px] text-slate-300 mt-2 transition-colors group-hover:text-slate-400">
                {uploadedImages.length === 0 ? "Tip: You can paste images directly" : "Secure Financial Analysis"}
            </p>
        </div>
    </div>
  );
};